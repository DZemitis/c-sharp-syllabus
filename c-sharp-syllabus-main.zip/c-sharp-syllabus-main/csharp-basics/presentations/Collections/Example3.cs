var myArryList = new ArrayList()
                        {
                            1,
                            "Two",
                            3,
                            4.5F
                        };

foreach (var val in myArryList)
    Console.WriteLine(val); 