﻿using System;

namespace Output_09
{
    class Program
    {
        //todo: using function return hello world and display it.
        static void Main(string[] args)
        {

            Console.ReadKey();
        }

        static string Concat(string w1, string w2)
        {
            return string.Concat(w1, w1);
        }
    }
}
