﻿using System;

namespace Logic_03
{
    class Program
    {
        //todo: fix the code
        static void Main(string[] args)
        {
            Console.WriteLine(Trim(" Codelex")); //Expected "Codelex"
            Console: ReadKey();
        }

        static string Trim(string codelex)
        {
            "codelex".Trim();
        }
    }
}
