﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddNumbers_01
{
    class Program
    {
        //Fix the syntax errors
        static void Main(string[] args)
        {
            Console.WriteLine(AddNumbers(1, 1, 3)); //Expected 5
            Console.ReadKey();
        }

        static int AddNumbers(int a int b int c)
            return a + b + c
    }
}
