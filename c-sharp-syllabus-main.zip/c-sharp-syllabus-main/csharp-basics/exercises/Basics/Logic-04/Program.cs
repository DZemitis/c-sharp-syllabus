﻿using System;

namespace Logic_04
{
    class Program
    {
        //todo: fix the code
        static void Main(string[] args)
        {
            Console.WriteLine(Multiply(1,3,4)); //Expected 12;
            Console.ReadKey();
        }

        static int Multiply(int a, int b, int c)
        {
            var z = a * b * c;
            return a;
        }
    }
}
