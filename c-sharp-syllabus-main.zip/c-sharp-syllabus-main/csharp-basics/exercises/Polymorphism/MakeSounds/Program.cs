﻿using System;

namespace MakeSounds
{
    class Program
    {
        private static void Main(string[] args)
        {
            
        }
    }
}