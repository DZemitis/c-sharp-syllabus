﻿namespace Exercise4
{
    class Program
    {
        //TODO: print all vowels using for and foreach
        static void Main(string[] args)
        {
            char[] vowels = {'a', 'e', 'i', 'o', 'u'};

            /*
            todo - use for
            for (?) 
            {
                Console.WriteLine(vowels[i]);
            }
            */

            /*
            todo - use foreach
            for (?) 
            {
                Console.WriteLine(vowel);
            }
            */
        }
    }
}
