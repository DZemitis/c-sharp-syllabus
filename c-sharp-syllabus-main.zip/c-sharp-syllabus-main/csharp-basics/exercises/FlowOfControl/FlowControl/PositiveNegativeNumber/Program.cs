﻿using System;

namespace PositiveNegativeNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number.");
            var input = Console.ReadKey();
            /*
            fixme
            if (?)
            {
                Console.WriteLine("Number is positive");
            } 
            else if (?) 
            {
                Console.WriteLine("Number is negative");
            } 
            else 
            {
                Console.WriteLine("Number is zero");
            }
            */
        }
    }
}
