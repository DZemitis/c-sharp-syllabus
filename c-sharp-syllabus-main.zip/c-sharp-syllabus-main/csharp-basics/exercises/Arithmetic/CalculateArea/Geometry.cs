﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateArea
{
    public class Geometry
    {
        public static double AreaOfCircle(decimal radius)
        {
            throw new NotImplementedException();
        }

        public static double AreaOfRectangle(decimal length, decimal width)
        {
            throw new NotImplementedException();
        }

        public static double AreaOfTriangle(decimal ground, decimal h)
        {
            throw new NotImplementedException();
        }
    }
}
