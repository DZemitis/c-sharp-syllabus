# Mini Projects

## Picture Viewer

Follow the instructions [here](https://github.com/MicrosoftDocs/visualstudio-docs/blob/master/docs/ide/tutorial-1-create-a-picture-viewer.md).

## Math Quiz

Follow the instructions [here](https://github.com/MicrosoftDocs/visualstudio-docs/blob/master/docs/ide/tutorial-2-create-a-timed-math-quiz.md).

## Memory Game

Follow the instructions [here](https://github.com/MicrosoftDocs/visualstudio-docs/blob/master/docs/ide/tutorial-3-create-a-matching-game.md).

## Minesweeper

Follow the instructions [here](./Minesweeper).

