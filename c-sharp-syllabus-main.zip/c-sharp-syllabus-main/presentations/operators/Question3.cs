boolean result = 1 < x < 3;
Console.WriteLine(result);
// output?