string[] array = { "Ron", "Harry", "Hermione" };

foreach (var x in array)
{
    Console.WriteLine(x);
}