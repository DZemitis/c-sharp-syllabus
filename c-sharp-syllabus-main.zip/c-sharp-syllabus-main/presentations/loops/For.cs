for (int i = 1; i <= 4; i++)
{
    Console.WriteLine("Value of i: " + i);
}