int x = 21;

do
{
    Console.WriteLine("Value of x: " + x);
    x++;
} while (x < 20);