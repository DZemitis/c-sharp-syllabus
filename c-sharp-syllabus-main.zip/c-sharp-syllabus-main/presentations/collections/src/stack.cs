Stack st = new Stack();
st.Push("Csharp");
st.Push(7.3);
st.Push(8);
st.Push('b');
st.Push(true);

// a) Unsimilar elements like “Csharp”,7.3,8 cannot be stored in the same stack collection.
// b) Boolean values can never be stored in Stack collection
// c) Perfectly workable code
// d) All of the mentioned