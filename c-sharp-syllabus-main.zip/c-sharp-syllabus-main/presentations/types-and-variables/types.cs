Int32 d = 5;
String hello = "Hello";
Console.WriteLine(d);
Console.WriteLine(hello);