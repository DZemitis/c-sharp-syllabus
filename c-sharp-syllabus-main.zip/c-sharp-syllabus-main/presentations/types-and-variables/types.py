x=10
print x
x="Hello world!"
print x