int i = x > 5 ? 0 : 1;
// i == 0 if condition was true, i == 1 otherwise