//What is the output?

int sum = 14;

if (sum < 20)
{
    Console.WriteLine("Under");
}
else
{
    Console.WriteLine("Over");
}

Console.WriteLine("The limit.");