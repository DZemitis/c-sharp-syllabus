//What is the output?

int sum = 21;

if (sum != 20)
{
    Console.WriteLine("You win.");
    return;
}
else
{
    Console.WriteLine("You lose.");
    return;
}

Console.WriteLine("The prize.");